using System;
using System.Drawing;
using System.IO.Ports;
using System.Windows.Forms;

namespace IsiNemArayuz
{
    // Auto-generated dosyalarla çakışmaması için ismini ArayuzPenceresi yaptık
    public class ArayuzPenceresi : Form
    {
        private SerialPort serialPort;
        private Label lblSicaklik;
        private Label lblNem;

        public ArayuzPenceresi()
        {
            // Form (Pencere) Tasarım Ayarları
            this.Text = "Isı ve Nem Ekranı";
            this.Size = new Size(400, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Etiket (Yazı) Ayarları
            lblSicaklik = new Label() { Text = "Sıcaklık: Veri Bekleniyor...", Location = new Point(30, 30), AutoSize = true, Font = new Font("Arial", 16, FontStyle.Bold) };
            lblNem = new Label() { Text = "Nem: Veri Bekleniyor...", Location = new Point(30, 80), AutoSize = true, Font = new Font("Arial", 16, FontStyle.Bold) };
            
            this.Controls.Add(lblSicaklik);
            this.Controls.Add(lblNem);

            // --- PORT AYARI ---
            serialPort = new SerialPort();
            serialPort.PortName = "COM3"; // KENDİ PORTUNUZU BURAYA YAZIN
            serialPort.BaudRate = 115200; // Arduino kodunuzdaki hız ile aynı olmalı
            serialPort.DataReceived += new SerialDataReceivedEventHandler(VeriGeldi);
            
            try {
                serialPort.Open(); // Portu dinlemeye başla
            } catch (Exception ex) {
                MessageBox.Show("Port açılamadı! Arduino Seri Monitörü açık unutmuş olabilirsiniz.\nHata: " + ex.Message, "Bağlantı Hatası");
            }
        }

        // Arduino'dan (Deneyap Karttan) USB ile veri geldiğinde burası çalışır
        private void VeriGeldi(object sender, SerialDataReceivedEventArgs e)
        {
            try {
                string data = serialPort.ReadLine();
                
                // Form arayüzünü güvenli bir şekilde güncellemek için Invoke kullanılır
                this.Invoke((MethodInvoker)delegate {
                    // C++ kodunuzdan gelen "TEMP:24.5,HUM:45.2" formatındaki veriyi yakala
                    if(data.Contains("TEMP:") && data.Contains(",HUM:")) {
                        // Veriyi parçalama işlemi
                        string[] parcalar = data.Split(',');
                        string temp = parcalar[0].Replace("TEMP:", "");
                        string hum = parcalar[1].Replace("HUM:", "");
                        
                        // Ekrana yazdırma
                        lblSicaklik.Text = "Sıcaklık: " + temp + " °C";
                        lblNem.Text = "Nem: " + hum + " %";
                    }
                });
            } catch { }
        }
    }

    // Programın başlangıç noktası
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // Kendi tasarladığımız pencereyi başlatıyoruz
            Application.Run(new ArayuzPenceresi());
        }
    }
}