
#include <Wire.h>
#include <DHT.h>
#include <LiquidCrystal_I2C.h>

// DHT22 bağlantısı
#define DHTPIN 21
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);

// LCD I2C adresi
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {

  Serial.begin(115200);

  // Deneyap Kart I2C pinleri
  Wire.begin(4, 15);

  // Sensörü başlat
  dht.begin();

  // LCD ekranı başlat
  lcd.init();
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("ISI VE NEM");
  lcd.setCursor(0, 1);
  lcd.print("Olcer Basladi");

  delay(2000);
  lcd.clear();
}

void loop() {

  float sicaklik = dht.readTemperature();
  float nem = dht.readHumidity();

  // Sensör kontrolü
  if (isnan(sicaklik) || isnan(nem)) {

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Sensor Hatasi!");

    Serial.println("ERROR");

    delay(2000);
    return;
  }

  // LCD sıcaklık
  lcd.setCursor(0, 0);
  lcd.print("Sicaklik: ");
  lcd.print(sicaklik, 1);
  lcd.print(" C   ");

  // LCD nem
  lcd.setCursor(0, 1);
  lcd.print("Nem: ");
  lcd.print(nem, 1);
  lcd.print(" %      ");

  // C# arayüzüne veri gönder
  Serial.print("TEMP:");
  Serial.print(sicaklik, 1);

  Serial.print(",HUM:");
  Serial.println(nem, 1);

  delay(2000);
}
